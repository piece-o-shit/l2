@extends('layouts.app')

@section('title', trans('default.form_layouts'))

@section('contents')
    <form-layouts></form-layouts>
@endsection
