@extends('layouts.app')

@section('title', trans('default.text_editor'))

@section('contents')
    <input-text></input-text>
@endsection
