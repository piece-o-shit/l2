{!! $template !!}

