@extends('layouts.app')

@section('title', trans('default.kanban_view'))

@section('contents')
    <kanban-view></kanban-view>
@endsection
