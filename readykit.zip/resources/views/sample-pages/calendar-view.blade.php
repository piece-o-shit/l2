@extends('layouts.app')

@section('title', trans('default.calendar_view'))

@section('contents')
    <calendar-view></calendar-view>
@endsection
