@extends('layouts.app')

@section('title', trans('default.chat'))

@section('contents')
    <chat></chat>
@endsection
