import Vue from 'vue';

Vue.component('modal', require('./Modal/Modal').default);
Vue.component('app-delete-modal', require('./Modal/DeleteModal').default);
