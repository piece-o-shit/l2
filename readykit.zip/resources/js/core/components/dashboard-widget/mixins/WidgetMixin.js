export const WidgetMixin = {
    props: {
        data: {
            default: null
        }
    }
};
